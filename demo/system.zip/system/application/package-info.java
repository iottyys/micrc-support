/**
 * 应用服务增
 * <p>
 * tengwang  缺失任务记录
 * 1. 缺失JSR303状态组样例
 * 2. 缺失应用服务样例
 * 3. 缺失API端口样例
 * 4. 缺失查询服务样例
 */
package io.ttyys.micrc.system.application;