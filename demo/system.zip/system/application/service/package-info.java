/**
 * 应用服务
 */
package io.ttyys.micrc.system.application.service;