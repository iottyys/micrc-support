/**
 * 查询模型 + 查询数据库操作工具 + 查询对象与界面呈现对象的转换映射
 */
package io.ttyys.micrc.system.presentation.model;