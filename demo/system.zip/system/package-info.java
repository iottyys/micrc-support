/**
 * 基础库子域
 */
package io.ttyys.micrc.system;