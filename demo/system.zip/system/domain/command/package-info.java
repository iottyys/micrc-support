/**
 * 业务操作 命令对象以及命令业务逻辑块
 */
package io.ttyys.micrc.system.domain.command;