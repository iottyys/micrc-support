/**
 * 集成服务
 */
package io.ttyys.micrc.system.domain.integration;
