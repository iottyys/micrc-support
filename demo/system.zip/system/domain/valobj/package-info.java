/**
 * 值对象
 */
package io.ttyys.micrc.system.domain.valobj;