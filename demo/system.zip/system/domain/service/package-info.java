/**
 * 领域服务
 */
package io.ttyys.micrc.system.domain.service;