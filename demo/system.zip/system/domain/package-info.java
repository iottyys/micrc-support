/**
 * 领域层
 */
package io.ttyys.micrc.system.domain;