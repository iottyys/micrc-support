/**
 * 领域状态变更事件
 */
package io.ttyys.micrc.system.domain.event;