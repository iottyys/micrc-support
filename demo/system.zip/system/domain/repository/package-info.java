/**
 * 资源库
 */
package io.ttyys.micrc.system.domain.repository;