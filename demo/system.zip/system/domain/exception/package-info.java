/**
 * 业务异常
 */
package io.ttyys.micrc.system.domain.exception;