/**
 * 领域模型
 */
package io.ttyys.micrc.system.domain.entity;