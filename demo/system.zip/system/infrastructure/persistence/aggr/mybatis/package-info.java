/**
 * mybatis对数据库的操作工具类
 */
package io.ttyys.micrc.system.infrastructure.persistence.aggr.mybatis;