/**
 * 领域资源库的实现包
 */
package io.ttyys.micrc.system.infrastructure.persistence.aggr;