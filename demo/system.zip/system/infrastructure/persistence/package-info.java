/**
 * 持久层实现
 */
package io.ttyys.micrc.system.infrastructure.persistence;