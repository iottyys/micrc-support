/**
 * 客户端api接口
 */
package io.ttyys.micrc.system.infrastructure.api.rpc;