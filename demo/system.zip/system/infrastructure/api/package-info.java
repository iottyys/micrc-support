/**
 * 远程调用
 */
package io.ttyys.micrc.system.infrastructure.api;