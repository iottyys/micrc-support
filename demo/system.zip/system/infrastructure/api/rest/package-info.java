/**
 * rest通讯
 */
package io.ttyys.micrc.system.infrastructure.api.rest;