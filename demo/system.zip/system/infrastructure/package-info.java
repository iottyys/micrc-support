/**
 * 基础设施层
 */
package io.ttyys.micrc.system.infrastructure;