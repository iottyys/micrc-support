/**
 * 消息
 */
package io.ttyys.micrc.system.infrastructure.message;